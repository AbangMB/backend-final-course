const authController = require("./authController");
const userController = require("./userController");
const cartController = require("./cartController");

module.exports = {
  authController,
  userController,
  cartController,
};
