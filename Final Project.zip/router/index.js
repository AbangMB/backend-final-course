const authRouter = require("./authRouter");
const userRouter = require("./userRouter");
const cartRouter = require("./cartRouter");

module.exports = {
  authRouter,
  userRouter,
  cartRouter
};
